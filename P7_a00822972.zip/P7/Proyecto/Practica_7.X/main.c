/*
 * File:   main.c
 * Author: ricky
 *
 * Created on November 15, 2020, 6:30 PM
 */


#include <xc.h>
#include <config.h>

void portInit(){

    ANSELB= 0;
    ANSELD= 0;
    TRISB= 0xF0; //11110000
    TRISD= 0x00;
    
}

void main (void){
    portInit();
    unsigned short fila = 0;
    unsigned short columna = 0;
    while(1){    
        
        while(1){
            if (fila <3 ){
                fila++;
            }
            else {
                fila=0;
            }
            switch(fila){
                case 0 : LATB|= 0x0E; break;//1110    11101110
                case 1 : LATB|= 0x0D; break;//1101      
                case 2 : LATB|= 0x0B; break;//1011    
                case 3 : LATB|= 0x07; break;//0111
                default: LATB&= 0x00; break;//0000
            }
            
            if (PORTB == 0xEE){ //1
                LATD <<=4;
                LATD |= 0x01;            
      
        }
            
            else if (PORTB == 0xDE  ){  //4
                LATD <<=4;
                LATD |= 0x04;  
            }
            
            else if (PORTB == 0xBE) { //7
                LATD <<=4;
                LATD |= 0x07; 
            
            
            }
            else if (PORTB == 0x7E) { //*
                LATD <<=4;
                LATD |= 0xE; 
            }
            
            else if (PORTB == 0xED ){ //2
            
                LATD <<=4;
                LATD |= 0x02;
                
            }
            
            
             else if (PORTB == 0xDD ){ //5
            
                LATD <<=4;
                LATD |= 0x05;
                
            }
              
             else if (PORTB == 0xBD ){ //8
            
                LATD <<=4;
                LATD |= 0x08;
                
            }
             else if (PORTB == 0x7D ){//0
            
                LATD <<=4;
                LATD |= 0x00;
                
            }
            
            else if (PORTB == 0xEB ){ //3
            
                LATD <<=4;
                LATD |= 0x03;
                
            }
            
            else if (PORTB == 0xDB ){//6
            
                LATD <<=4;
                LATD |= 0x06;
                
            }
              else if (PORTB == 0xBB ){//9
            
                LATD <<=4;
                LATD |= 0x09;
                
            }
            
           else if (PORTB == 0x7B ){//#
            
                LATD <<=4;
                LATD |= 0xF;
                
            }
          else if (PORTB == 0xE7 ){//A
            
                LATD <<=4;
                LATD |= 0xA;
                
            }
          
          else if (PORTB == 0xD7 ){//B
            
                LATD <<=4;
                LATD |= 0xB;
                
            }      
        
            else if (PORTB == 0xB7 ){//C
            
                LATD <<=4;
                LATD |= 0xC;
                
            }      
                else if (PORTB == 0x77 ){//D
            
                LATD <<=4;
                LATD |= 0xD;
                
            } 
            
        }
        
    
    }
    
    
    return;

}


