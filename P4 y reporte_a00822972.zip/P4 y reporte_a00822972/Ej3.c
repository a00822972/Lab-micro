#include<stdio.h> 
int main(){

	int num = 5; //numero a introducir
	int i = num;
    int resultado = 0; // inicializacion de la variable de resultado
    int K; //contador que controla el ciclo while
    
    /*A continuaci�n, en todo bit que sea uno, se ir�n sumando
    sus respectivos valores, dando como resultado el cuadrado.*/
        while(i > 0){
            if((i & 1) == 1){
                resultado += num << K;
            }
            i = i >> 1;
            K++;
        }    // el ciclo while suma los corrimientos realizados cada ciclo. Se va actualizando el valor cada ciclo como una operacion read modify
        
        printf(" %d^2 es %d",num, resultado);
        return resultado;
    }
