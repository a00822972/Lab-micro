#include <stdio.h>   ///incluicion de librerias
#include <math.h>
    
  int multiplicaciondiv(int num1, int num2)  // declaracion de funcion de multiplicacion-division
    { 
	    if (num1<0 && num2<0) //se incluye este if para evitar tener problemas con numeros negativos
		{
		 num1=num1*(-1);
		 num2=num2*(-1);
		}
		 if (num1>0 && num2<0) //se incluye este if para evitar tener problemas con numeros negativos
		{
		 num1=num1*(-1);
		 num2=num2*(-1);
		}
        int resultado = 0;   
        while (num2 > 0)  //cada ciclo del while se realizan corrimientos de bits y se suman los resultados. Num2 controla el numero de ciclos, num1 es sumado al resultado
        { 
             if ((num2 & 1) != 0) 
                 resultado = resultado + num1; 
            num1 = num1 << 1; 
            num2 = num2 >> 1; 
        } 
        return resultado; 
    } 
 int main(void)
    {   
    
	 int num1 = 10;	  
	 int num2 = 5;      
     printf("Resultado es %d",multiplicaciondiv(num1, num2));  //para dividir, multiplicar por reciproco	
	 return 0;        
   }
