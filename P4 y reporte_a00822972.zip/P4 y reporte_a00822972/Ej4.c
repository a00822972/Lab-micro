#include <stdio.h>  //inclucion de librerias
#include <math.h>
   int k;     //iniciacion de variables
   int valor;
   int incremento;

void Binario(incremento) //declaracion de funcion que convierte a binario
{
    int j;
    for(int i =8; i >= 0; i--)  //ciclo for produce la secuencia de 1 y 0
    {
        j = k >> i;
        
        if(j & 1)
            printf("1");
        else
            printf("0");
    }
    printf("__");
}
int main() 
{
   int k;    //declaracion de variables en el main 
   int exp;
   int valor;


   incremento = 0; //se inicializa el incremento en 0 para poder controlar el while
   exp= 3;
   valor = pow(2,exp) - 1;
   while ( k <= valor )        // ciclo while ejecuta la funcion que genera las secuencias 1 y 0 
   {
      Binario(k); 
      incremento++;    
   }

    return 0;
}
