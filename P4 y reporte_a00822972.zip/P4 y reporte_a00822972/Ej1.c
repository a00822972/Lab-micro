#include <stdio.h> 
int Deteccion(int A[], int K)    //declaracion de funcion de deteccion del elemento unico
{ 
      //Inicializacion de elementos
	int Array1 = 0;  //el array manejado se descompone en dos para poder comparar los bits
    int Array2 = 0;  // segundo array a comparar
    int Num_detectar;  // numero a detectar
  
  
    for(int i = 0; i < K; i++) {     //algoritmo de deteccion, num de ciclos depende del tamano del arreglo manejado

        Array1 = Array2 | (Array1 & Array2[i]);  //El or permite la preservacion de los valores
      
        Array1 = Array2 ^ A[i];  // se utiliza un xor para convertir todo a valores impares
    
        Num_detectar = ~(Array1 & Array2);  // se depuran los bits en comun entre lo dos arrays
     
        Array1 &= Num_detectar;  //se borran los bits en comun tanto de los dos arrays manejados
    
        Array2 &= Num_detectar; 
        
    } 
    return Array1;  //elemento que no se repite
} 
int main() 
{ 
    
	int A[] = {10, 1, 10, 3, 10, 1, 1, 2, 3, 3};  //arreglo manejado, puede ser cualquier otro
    int K = sizeof(A) / sizeof(A[0]);  //esta variable define el numero de iteraciones que tendra el algoritmo de deteccion
    printf("%d solo se repite una vez ", Deteccion(A, K)); 
} 
